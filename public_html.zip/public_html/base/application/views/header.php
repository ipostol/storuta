<?php
echo <<<LABEL
<!DOCTYPE html>
<html lang='en'>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="{$params['url']}ico/favicon.ico" rel="shortcut icon" type="image/x-icon" />
<link href="{$params['url']}css/bootstrap.css" rel="stylesheet">
<link href="{$params['url']}css/menu.css" rel="stylesheet">
<link href="{$params['url']}css/records.css" rel="stylesheet">
<link href="{$params['url']}css/jquery-ui.min.css" rel="stylesheet">
<script src="{$params['url']}js/jquery.js"></script>
<script src="{$params['url']}js/round.js"></script>
<script src="{$params['url']}js/jquery-ui.min.js"></script>

</head>
LABEL;
?>