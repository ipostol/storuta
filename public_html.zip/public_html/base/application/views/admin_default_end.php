<?php
	echo <<<LABEL
	<a href="#"><img src="{$params['url']}ico/up.png" id="up" width="50px"/></a>
	<img src="{$params['url']}ico/loading.png" class='loading_off' alt="" id="rotateImg"/>
	</div>
	</body>
	</html>	
LABEL;
?>