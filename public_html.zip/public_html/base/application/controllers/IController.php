<?php
interface IController {
}
?>