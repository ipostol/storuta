<?php
class IndexController implements IController {
	public function indexAction() {
		$fc = FrontController::getInstance();	
		/* Инициализация модели */
		session_start();
		if(md5($_POST['password'])=='0aba0ff838dfc27b9c8b3cb9d40abff9'){
			$_SESSION['login']='true';
			$_SESSION['name']=$_POST['name'];
			header("Location: http://".$_SERVER['HTTP_HOST']."/base");
		}
		if($_SESSION['login']=='true'){
			$model = new IndexModel();
			$output = $model->render('');
		}
		else{
			$model = new IndexGuestModel();
			$output = $model->render('../views/user_default.php');
		}
		$fc->setBody($output);
	}
}
?>